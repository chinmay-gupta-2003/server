const express = require('express');
const app = express();
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const test = require('./route/testRoute.js');
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

app.use('/test', test);

app.listen(3000, () => {
  console.log('Example app listening on port 3000!');
});
