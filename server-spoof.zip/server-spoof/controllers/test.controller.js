const testModel = require('../models/test.model');

exports.test = (req, res, next) => {
  res.send('Greetings from the Test controller!');
};
