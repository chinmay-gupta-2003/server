const express = require('express');
const router = express.Router();

const test_controller = require('../controllers/test.controller.js');

router.route('/test').get(test_controller.test);
